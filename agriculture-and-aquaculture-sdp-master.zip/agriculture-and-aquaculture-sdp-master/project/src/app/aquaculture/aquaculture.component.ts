import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aquaculture',
  templateUrl: './aquaculture.component.html',
  styleUrls: ['./aquaculture.component.css']
})
export class AquacultureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
