import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'project';

  agriculture = [
    { name:'Want To Know About Agriculture briefly',image:'\assets\IMAGES\Agriculture1.jpg',link:'/agriculture'},
    { name:'Want To Know About Aquaculture briefly',image:'\assets\IMAGES\Aquaculture1.jpg',link:'/aquaculture'}
  ]
  

  contactus = [

    {name:"contact",link:"/contact"},
  ]

  home =[
    {name:"home",link:"/home"}
  ]

}
